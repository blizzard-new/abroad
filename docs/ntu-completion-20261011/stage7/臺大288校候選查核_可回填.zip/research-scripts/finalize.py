from pathlib import Path
from collections import Counter
import json,hashlib,datetime,shutil,zipfile,re
from openpyxl import load_workbook
R=Path('/workspace/abroad-ntu-completion-20261011');D=R/'docs/ntu-completion-20261011';S=D/'stage7';V=S/'validation';H=Path(__file__).parent
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
write=lambda p,x:p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
snap=read(R/'sources/ntu/completion-2026-10-11.json');matrix=read(S/'all-school-review.json');summary=read(S/'review-summary.json');progress=read(R/'sources/ntu/priority-review-progress-current-2026-10-11.json');m=read(R/'sources/ntu/reviewed-source-bodies-current-manifest.json');manual=read(R/'sources/ntu/semantic-review-current-2026-10-11.json');ledger=read(R/'sources/ntu/full-body-review-current-2026-10-11.json')
assert sha(V/'tested-source-snapshot.json')==sha(R/'sources/ntu/completion-2026-10-11.json');assert summary['new_observations']==700 and len(matrix)==4032
run=read(V/'run-receipt.json');assert run['source_sha256']==sha(V/'tested-source-snapshot.json')
assert run['summary_adapter_sha256']==sha(R/'src/exchange_info/ntu_partner_summary.py')
assert all(sha(R/p)==s for p,s in run['test_files_sha256'].items())
assert all(sha(R/p)==s for p,s in run['materialized_files_sha256'].items())
assert sha(R/'scripts/verify_ntu_reviewed_source_archives.py')==run['archive_verifier_after_full_suite']['sha256']
repo_archive=read(V/'repo-archive-verifier.log');assert repo_archive['current_bodies']==554 and repo_archive['reviewed_citations']==347 and repo_archive['all_quote_pages_match']
visibility=read(V/'summary-visibility-all-700.json');assert visibility['all_700_references_text_scope_and_URL_in_first_10_display_points'] and visibility['summary_adapter_sha256']==run['summary_adapter_sha256']
results={}
for name in ['full-regression','browser','pr8-combined-browser','pr8-combined-focused','new-reference-browser']:
 text=(V/(name+'.log')).read_text();last=next((line for line in reversed(text.splitlines()) if re.search(r'\d+ passed',line)),None);assert last and 'failed' not in last,(name,'must pass first');results[name]={'final_line':last,'source_sha256':sha(V/'tested-source-snapshot.json'),'summary_adapter_sha256':run['summary_adapter_sha256'],'log':name+'.log'}
book=load_workbook(S/'288校逐欄查核_可回填.xlsx',read_only=True);sheets={s.title:s.max_row-1 for s in book};assert len(sheets)==7 and sheets['288校逐欄回填']==4032 and sheets['固定501項正文進度']==501 and sheets['逐源全文閱讀紀錄']==581 and sheets['來源原文索引']==348;assert not any(c.data_type=='f' for s in book for row in s for c in row);book.close()
write(V/'summary.json',{'tested_source_sha256':sha(V/'tested-source-snapshot.json'),'summary_adapter_sha256':run['summary_adapter_sha256'],'observations':700,'tests':results,'all_700_references_visible_with_scope_and_URL':True,'run_receipt':run,'repo_archive_verifier_after_full_suite':repo_archive,'excel':{'sheet_rows':sheets,'formula_cells':0,'GUI_visual_workbook_review_performed':False},'scope':read(V/'scope-and-rebuild.json'),'archive':read(S/'archive-verification.json'),'pr8_intersection':read(H/'pr8-intersection.json'),'original_ten_field_fully_verified_rows':0,'merge_or_deploy':False})
pending={r['portal_id'] for r in matrix if r['field']=='quota' and not r['target_requirement_confirmed']};tenfields={'quota','eligibility','language','documents','deadlines','calendar','housing','cost','courses','insurance_visa'};ten=[r for r in matrix if r['portal_id'] in pending and r['field'] in tenfields];assert len(ten)==2820 and not any(r['target_requirement_confirmed'] for r in ten)
coverage={'school_denominator':282,'field_denominator':10,'rows':len(ten),'fully_verified_rows':0,'old_workbook_retrieved':False,'old_exact_membership_comparison_available':False,'publication_statuses':dict(Counter(r['publication_status'] for r in ten)),'readable_unread_rows':sum(bool(r['unread_candidate_body_count']) for r in ten),'exclusive_external_blocker_rows':sum(r['external_blocker_exclusive'] for r in ten)};write(S/'282-school-ten-field-coverage.json',coverage)
base=read(D/'stage6/daily-baseline-2026-10-11.json');base.update(stage='stage7_41_references_materialized',research_checkpoint_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_snapshot_sha256=sha(V/'tested-source-snapshot.json'),reviewed_observations=700,runtime_validated_observations=700,incremental_imported_observations=41,incremental_unimported_observations=0,reviewed_source_quotes=347,archived_body_count=554,manual_semantic_decisions=len(manual),unread_public_body_rows=summary['readable_unread_rows'],fixed_priority_progress={k:v for k,v in progress.items() if k!='fields'},new_host_retrieval_window_utc=['2026-10-11T15:01:22+00:00','2026-10-11T15:05:53+00:00'],timestamp_note='本批来源各自保留checked_at；臺大正式三入口實際最後讀取UTC10:42，288詳情08:31–08:37。重建／測試／整理不是全網重查日期。');write(S/'daily-baseline-2026-10-11.json',base)
shutil.copyfile(R/'sources/ntu/completion-2026-10-11.json',S/'結構化候選資料.json');shutil.copyfile(R/'sources/ntu/reviewed-source-bodies-current-manifest.json',S/'reviewed-source-bodies-manifest.json')
for filename in ['46-life-gap-source-origin-comparison.json','remaining-independent-host-life-research.json']:shutil.copyfile(D/'stage4'/filename,S/filename)
report=f'''# 第七批：700則已匯入參考；142/501原優先本文集合完成

照片仍缺3校：加州大學(9)、加州州立大學(12)、特魯瓦科技大學(67)。座標仍缺3校：加州大學(9)、加州州立大學(12)、蒙斯大學(1302)。UC/CSU的臺大正式profile未指定分校，不能拿總部或任選校區補。特魯瓦[官方legal頁](https://www.utt.fr/mentions-legales)再製要求許可；Commons候選未取得能同時驗本體、作者、授權的照片，未向校方發信。蒙斯[比利時官方校頁](https://www.studyinbelgium.be/en/universite-de-mons)已核Place du Parc20；官方校圖讀取不可用，Charleroi、BdDolez31與Warocque17候選地址／校區不同或缺交叉核對。具體收據沿用[資產證據](../stage4/evidence/asset-gap-review.json)。這兩批沒有新資產；之前核可照片19、代表座標16筆維持。

## 已完成的分支更新

先把第五批51則按原scope匯入，608→659，發布固定commit **6417aaa38fb1172aa3ad95f8cbc0c7ea62a02d3a**，來源SHA **37ffe53b371ab6a3017ca554941d374256f1699ef92560f8be32463d5dcf12c8**。該版完整2185通過／13略過，臺大browser13、固定PR8browser26、視覺座標內容23、守門14均通過，4份交付遠端下載byte一致；[固定commit收據](第六批固定commit核對收據.json)。第五批候選未匯入的問題已處理。

本批再完整讀關西學院、橫濱國立、東京外大、名古屋外大與秋田原優先正文，共40個原sourceID；另循公開連結6份正文完整讀取，6次robots不可用／不允許另記。**新增41則，659→700**，已重建partner application_info与destination學生指南；[41則匯入增量](第七批41則已匯入增量.json)有原文片段、URL、原版本SHA、原學年／學期／programme／校區範圍、頁碼及checked_at。沒有把這批只留成Excel候選。每項`selection_rule_confirmed=false`；只在同一Draft PR9，未merge/deploy，不能說正式網站已上線。

新校瀏覽器查核發現合作校摘要原先只顯示前10段，TUFS後面的費用舊年／冬季矛盾會被截去。已在NTU專用摘要按9個參考欄位合併段落，全部700則正文、適用範圍與URL仍在首10個顯示項內；sharedapp.js未改。四項TUFS／KGU手機與桌面回歸檢查已通過。初次失敗紀錄、實際截斷原因與預期字串修正均保留在validation；没有修改來源來迎合測試。完整與PR8組合檢查均在此修正後重跑，先前成功但修正前的logs以before-summary-grouping名稱另存。

## 有用發現與問題處理

- **東京外大TUFS AY2027**：官方4頁新資訊表9/17/2026發布，雖URL含SpringEntry，p1明列Fall2027從Jan開初申、**2027/3/15截止**。不是把舊日期改年，也沒有把Spring2027 checklist當Fall2027新版。初申GPA2.0/4.0與JASSO2.3/3.0的量尺／計算期分開；英B2或日N2與母校信替代、母語仍需說明信分開。七項公開文件与提名後入口password分開；COE同初申deadline、不是錄取後才開始所有COE資料。p3宿舍床具15000比2025/26的12100不同原年。p4校方保險費明确括注AY2026，不採作2027确定費率。p1冬季起年印EarlyFebruary2027而終點March31,2028，目視也是如此，保留版本內部矛盾，沒有自行改成2028。3張核對圖見[evidence](evidence/visual-evidence-manifest.json)，p1/3/4全部SHA核對。
- **關西學院CJP**：新的26/27兩頁要項與原25/26分開；JLT平片假名、英71expected且不要求英文cert，N1是一般日語本科選課條件。未標年general提名/初申日月仍tentative；2027春11/15/2026截止是此前入學批次，不套116-1。春文件最多14份、格式／教授自傳文件05／母校提交分階段；Jotform連結已公告但robots不允許路徑，不說全未公告。programme與整段宿費／月生活費分開。2026–27退寮1/19、IBA可延與舊2025秋網頁1/31並非同年任選。
- **橫濱JOY**：原2023SXIP活動、YNU赴外語學、在校LMS候選的身分誤配已拒用；JOY是協定校全日制本科，可英或日，2026新舊TOEFL量尺保留。提名deadline/details明說送母校，學生link提名後送；文件未列與特定階段取得分開。Tokiwadai學生Shared38000＋7000＋15510/月及一次不退66000，研究員房型費率不混入；寮auditor排除與JOY个人接收身分仍須核對，未誇大成個人住房保證。
- **名古屋外大**：特別聽講本科N2／研N1、2026春起不收母校日語能力信，與GJP placement日語課不同。地方活動工作申請不作incoming門檻；2026課表不當2027–28。特別聽講不可修GJP；住房偏好非指定保證，one-time／semester／monthly費率分開。
- **秋田1198**：原5份候選全是Akita International University (web.aiu.ac.jp)，臺大正式profile明列Akita University／AUAJ與AUGP(akita-u.ac.jp)。錯校資料全部拒用，平台此校沒有新增AIU事實；另核既有照片題名與身分Q1340164是AkitaUniversity，沒有因此任意改照片或坐標。正確官方program與April2027征集入口已辨識，索引显示9/8/2026公告；實际robots302重導soft404 HTML200、不是有效robot政策，未忽略或繞過取正文。正文／附件未得，不能說「確實未公告」。[逐項語意紀錄](第七批22項語意待解.json)与[robots重導證據](evidence/akita-robots-redirect-check.json)保留不同限制。

正式來源索引與頁碼在JSON／Excel；12次新來源訪問收據及robots在evidence。個人簽證仅按校方程序作有範圍參考，未推臺灣個案法律結果；没有發信、登入或绕封鎖。

## 覆蓋與剩餘工作

引用来源347；逐校逐欄逐來源版本完整閱讀581列（原集合375、另循公開文件206）、人工語意302列。554個本文版本／553sourceID由19件ZIP按SHA保存，前511版本／18分件逐項不變，本批增加43版本／1件。700則全部來源引用索引及本批41則片段／PDF頁碼已核；前後共30張PDF目視證據驗SHA。

固定分母仍**501校欄／117校／890個原候選本文SHA**，完成原cached全集**142/501**，仍**359項待續**，40校至少有一組完成。[359項工作集](尚待閱讀359項.json)保留原sourceID与SHA對照，可继续接續；完整閱讀不等整欄當期規定已核實，也不代表所有新增公開連結跟到底。

Repo封存驗證工具已修正以source_id＋raw SHA辨識同URL多版本，並支持舊分件未存逐頁JSON時從已驗SHA的原PDF取頁；影像式熊本PDF則核手抄原文、原PDF SHA與12張已目視的render證據SHA。本工具在全套測試完成後單獨修正並用全554版本／347引用、302語意紀錄與歷史59件實跑通過；11頁由原PDF重取、1頁依人工目視證據核對，具體方法另列，不混稱全部自動文字抽取。runtime來源、src、測試檔與全套使用版本一致；工具自身修正後SHA及結果另在run-receipt及repo-archive-verifier.log。

全288校×14欄4032列保留；當日282待定校×10類2820列保留，完整當期核實仍0列／0校。具年局部事實、舊版、未標年、確實官方明說待發布、已讀但未找到、未讀正文、錯校／錯身分與母校／提名／錄取後取得分開。全矩陣可讀未讀{summary['readable_unread_rows']}列，原十類{coverage['readable_unread_rows']}列；纯外部限制{summary['exclusive_external_blocker_rows']}列，原十類{coverage['exclusive_external_blocker_rows']}列。可讀未讀是工作，不稱外部阻礙。

任一官方生活段落272校／1963段，仍缺16校；原46校独立接待校生活來源仍缺38校，兩分母分開。這兩批92則沒有新增生活段落，不能稱16/38生活缺口已解。

## 臺大基準、測試與交付

116-1時程與正式簡章已公告：臺灣2026/11/3 10:00–11/9 16:00報名。當日名單282格空白、6格0，不取舊profile或hostcapacity當本期臺大名額。臺大最後實際3入口查核UTC10:42，288詳情08:31–08:37；這批重建／测试时间不當全校網站新checktime。原2026-10-07工作簿未取得，以當日288portalIDs重建只能保留當日282待定集合，不能宣稱與舊282逐格／成員完全相同。[每日基準](daily-baseline-2026-10-11.json)可供父端排程比對，没有建立重複排程。

当前700來源SHA **{sha(V/'tested-source-snapshot.json')}**、NTU摘要adapter SHA **{run['summary_adapter_sha256']}**，全套與NTU／固定PR8組合browser／focused結果在[驗證摘要](validation/summary.json)，每次測試绑來源及修正後程式SHA，materialized檔與測試檔SHA在run-receipt；前659完整全套另有自己的快照。全288正式資格、臺大名額、申請截止、狀態及身份/sourceURL和main逐項相同；workflows與其他母校資料byte一致，兩步重建byte-idempotent；PR8固定9927ec…在隔離樹组合，座標變更record交集空，沒有改PR8／main／sharedapp.js。

Excel7表、4032列／348索引／302人工語意／501進度／581閱讀与0公式皆核，未宣稱Excel GUI全表目視。Library先前401且父端停止重試，沒有檔案ID，交付以同Draft PR固定commit下載。前6批保留各自状态。父端11校本批未輸入，沒等待或偽造結果。此為有實際分支匯入與完整重驗的階段成果，仍359組原優先本文與當期未定子項可继续，不是全部缺口已解。
''';(S/'問題解決報告.md').write_text(report)
for filename in ['問題解決報告.md','review-summary.json','288校逐欄查核_可回填.xlsx','結構化候選資料.json','all-school-review.csv','all-school-review.json','daily-baseline-2026-10-11.json','282-school-ten-field-coverage.json','46-life-gap-source-origin-comparison.json','remaining-independent-host-life-research.json']:shutil.copyfile(S/filename,D/filename)
for p in H.glob('*.py'):
 dst=S/'research-scripts'/p.name;dst.parent.mkdir(exist_ok=True);shutil.copyfile(p,dst)
a=S/'臺大288校候選查核_可回填.zip'
with zipfile.ZipFile(a,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in S.rglob('*'):
  if p.is_file() and p!=a and p.suffix!='.zip' and p.name!='tested-source-snapshot.json':z.write(p,p.relative_to(S))
 z.write(R/'sources/ntu/priority-original-cached-texts-2026-10-11.zip','接續原候選文字.zip')
 z.writestr('原始本文說明.txt','19個本文分件在同repo sources/ntu，以本包manifest驗SHA。前27張PDF核對圖在stage4/evidence、stage5/evidence；本批3張在本包evidence。\n')
shutil.copyfile(a,D/a.name);write(S/'deliverables-manifest.json',[{'path':str(p.relative_to(R)),'size_bytes':p.stat().st_size,'sha256':sha(p)} for p in [S/'288校逐欄查核_可回填.xlsx',S/'問題解決報告.md',S/'結構化候選資料.json',a]])
(D/'README.md').write_text('''# 臺大288校研究與Draft PR9資料交付\n\n最新为[第七批報告](stage7/問題解決報告.md)、[Excel](stage7/288校逐欄查核_可回填.xlsx)、[JSON](stage7/結構化候選資料.json)与[回填ZIP](stage7/臺大288校候選查核_可回填.zip)。current別名同第七批；前6批各自保留，原第五批51則未匯入狀態是歷史快照，第六批已匯入重驗。\n\n第六批先608→659、第七批再659→700，92則皆實際匯入Draft PR9且完整重驗，来源SHA与測試结果见各批validation/summary.json。未merge/deploy。固定501項优先正文完成142、359項仍待續；原2820列完整當期核實仍0。照片UC/CSU/特魯瓦、坐標UC/CSU/蒙斯各缺3；任一生活来源缺16校，原46校独立生活來源缺38校。\n\n554本文版本以19件ZIP按SHA保存；原932sourceID／890rawSHA未核實抽取文字另在sources/ntu可攜ZIP。Library先前401，父端停止重試，沒有LibraryID；固定GitHubcommit作接續入口。最新發現包括TUFS2027秋正式日期与文內冬季年份矛盾、秋田大学/AIU错校拒用，範圍与證據见报告。\n''')
print(json.dumps({'observations':700,'source_sha':sha(V/'tested-source-snapshot.json'),'sheets':sheets,'tests':results},ensure_ascii=False))
