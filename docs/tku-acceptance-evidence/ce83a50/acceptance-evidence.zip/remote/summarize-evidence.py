from pathlib import Path
from collections import Counter
import json,hashlib,xml.etree.ElementTree as ET
ROOT=Path('/tmp/tku-ci-ce83a50'); ART=ROOT/'remote-artifacts'; CODE='ce83a502e33a42906fdf716bfaa606e777970d61'
prior=Path('/tmp/tku-ci-browser-3ccbf7c/remote-artifacts')
old_nodes=set()
for aid in [11590068725,11590222489,11590271662,11590526575]:old_nodes.update((prior/str(aid)/'collect-nodeids.txt').read_text().splitlines())
assert len(old_nodes)==1757
old_failed={x['id'] for x in json.load(open('/tmp/tku-acceptance-4e6cabd/ci-pr-complete-case-results.json')) if x['status']=='failed'};assert len(old_failed)==66
result={'head_sha':CODE,'pr_merge_sha':'291af195ffcd7e7e733b3d26d0a231d414037bff','same_code_tree':'37eed24b4a0224234592bd4c63896d2645fe936a','runs':{},'acceptance_waiver':False}
for kind,run_id in [('pr',37873683592),('push',37873678412)]:
 meta=json.load(open(ROOT/(kind+'-artifacts.json')));rows=sorted(meta['artifacts'],key=lambda x:int(x['name'].rsplit('-',1)[1]));assert len(rows)==4
 counts=Counter();controls=Counter();allnodes=[];case_rows=[];control_cases=[];shards=[]
 for row in rows:
  aid=row['id'];folder=ART/str(aid);actual=json.load(open(folder/'result.json'));partition=json.load(open(folder/'partition.json'));nodes=(folder/'collect-nodeids.txt').read_text().splitlines();allnodes+=nodes
  assert actual['tested_commit']==(result['pr_merge_sha'] if kind=='pr' else CODE);assert actual['shard']==partition['shard']
  aliases={(n.rsplit('::',1)[0].replace('.py','').replace('/','.').replace('::','.'),n.rsplit('::',1)[1]):n for n in nodes};shard_counts=Counter();tested=[]
  for c in ET.parse(folder/'suite.xml').getroot().iter('testcase'):
   status='failed' if c.find('failure') is not None else 'error' if c.find('error') is not None else 'skipped' if c.find('skipped') is not None else 'passed'
   node=aliases.get((c.attrib['classname'],c.attrib['name']));shard_counts[status]+=1
   if node is None:
    assert c.attrib['classname']=='pytest' and c.attrib['name']=='internal'
    continue
   tested.append(node)
   cause=c.find('failure');cause=c.find('error') if cause is None else cause
   case_rows.append({'id':node,'status':status,'seconds':float(c.attrib.get('time',0)),'shard':partition['shard'],'message':cause.attrib.get('message','') if cause is not None else ''})
  assert len(tested)==len(set(tested)) and set(tested).issubset(set(nodes))
  ctl=json.load(open(folder/'main-control/result.json'));assert ctl['candidate_commit']==actual['tested_commit'];assert ctl['acceptance_waiver'] is False
  assert ctl['baseline_commit']=='f6ad1b8cedc4dadb4d00c29eb3456a7a87856d59';assert ctl['unchanged_test_source_commit']=='4e6cabd073e4792f94959545efeb4e323fefc3f5';assert all(x.split('::',1)[0] in partition['files_per_shard'][partition['shard']] for x in ctl['cases']);control_cases+=ctl['cases']
  ctl_counts=Counter('failed' if c.find('failure') is not None else 'error' if c.find('error') is not None else 'skipped' if c.find('skipped') is not None else 'passed' for c in ET.parse(folder/'main-control/suite.xml').getroot().iter('testcase'));assert sum(ctl_counts.values())==len(ctl['cases'])
  assert hashlib.sha256((folder/'main-control/pytest.log').read_bytes()).hexdigest()==ctl['log_sha256'];controls.update(ctl_counts);counts.update(shard_counts)
  shards.append({'shard':partition['shard'],'artifact_id':aid,'actual_result':actual,'counts':dict(shard_counts),'collected_nodes':len(nodes),'executed_nodes':len(tested),'missing_nodes':len(set(nodes)-set(tested)),'complete':set(tested)==set(nodes),'archive_sha256':hashlib.sha256((ART/(str(aid)+'.zip')).read_bytes()).hexdigest(),'main_control_counts':dict(ctl_counts),'main_control_actual_exit':ctl['pytest_exit_code'],'same_job_same_runner_control':True})
 assert len(allnodes)==len(set(allnodes))==1764;assert not old_nodes-set(allnodes);assert len(set(allnodes)-old_nodes)==7;assert len(control_cases)==len(set(control_cases))==62
 passed={x['id'] for x in case_rows if x['status']=='passed'}; exercised={x['id'] for x in case_rows};failed={x['id'] for x in case_rows if x['status'] in ['failed','error']};unrun=sorted(old_failed-exercised);resolved=sorted(old_failed&passed);remaining=sorted(old_failed&failed);added=sorted(failed-old_failed)
 triage={'original_failed_nodes':66,'resolved_original_nodes':len(resolved),'resolved':resolved,'remaining_original_nodes':len(remaining),'remaining':remaining,'unrun_original_nodes':len(unrun),'unrun_original':unrun,'new_failed_nodes':len(added),'new_failed':added,'acceptance_waiver':False,'criterion':'Original IDs retained in collect. Only actually exercised passing original failures counted resolved; unrun explicitly separate.'}
 result['runs'][kind]={'run_id':run_id,'counts':dict(counts),'collected_nodes':1764,'collected_files':182,'executed_nodes':sum(x['executed_nodes'] for x in shards),'all_cases_exercised':all(x['complete'] for x in shards),'missing_nodes':sum(x['missing_nodes'] for x in shards),'duplicate_nodes':0,'removed_nodes':0,'added_regression_nodes':7,'same_job_main_control_counts':dict(controls),'main_control_nodes':62,'shards':shards,'original_failure_comparison':triage}
 (ROOT/(kind+'-case-results.json')).write_text(json.dumps(case_rows,ensure_ascii=False,indent=2)+'\n');(ROOT/(kind+'-original-failure-triage.json')).write_text(json.dumps(triage,ensure_ascii=False,indent=2)+'\n')
result['original_candidate_junit_count']=8;result['original_main_control_junit_count']=8;result['all_checks_passed']=all(v['counts'].get('failed',0)==v['counts'].get('error',0)==0 for v in result['runs'].values())
(ROOT/'complete-evidence-summary.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print({k:{'counts':v['counts'],'comparison':{x:v['original_failure_comparison'][x] for x in ['resolved_original_nodes','remaining_original_nodes','new_failed_nodes']}} for k,v in result['runs'].items()})
